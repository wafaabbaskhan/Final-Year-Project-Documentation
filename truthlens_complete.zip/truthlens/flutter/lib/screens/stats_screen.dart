// lib/screens/stats_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../theme.dart';
import '../services/history_service.dart';
import '../models/detection_result.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Statistics')),
      body: Consumer<HistoryService>(
        builder: (_, hs, __) {
          final stats   = hs.stats;
          final history = hs.history;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── 4 stat boxes ────────────────────────────────────────
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.6,
                  children: [
                    _StatBox(
                        value: '${stats?.totalVerified ?? history.length}',
                        label: 'Articles verified',
                        color: AppColors.textPrimary),
                    _StatBox(
                        value: '${stats?.totalFake ?? history.where((r) => r.verdict == 'fake').length}',
                        label: 'Flagged as fake',
                        color: AppColors.verdictFake),
                    _StatBox(
                        value: '${stats?.totalReal ?? history.where((r) => r.verdict == 'real').length}',
                        label: 'Confirmed real',
                        color: AppColors.verdictReal),
                    _StatBox(
                        value: '${stats?.totalUncertain ?? history.where((r) => r.verdict == 'uncertain').length}',
                        label: 'Uncertain',
                        color: AppColors.verdictUncertain),
                  ],
                ),
                const SizedBox(height: 16),

                // ── Pie chart ────────────────────────────────────────────
                if (history.isNotEmpty) ...[
                  _SectionCard(
                    title: 'Verdict distribution',
                    child: SizedBox(
                      height: 180,
                      child: _VerdictPieChart(history: history),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],

                // ── Bar breakdown ────────────────────────────────────────
                _SectionCard(
                  title: 'Verification breakdown',
                  child: Column(
                    children: [
                      _BarRow(
                        label: 'Fake',
                        value: stats != null
                            ? stats.fakePct / 100
                            : _pct(history, 'fake'),
                        color: AppColors.verdictFake,
                        pctText: stats != null
                            ? '${stats.fakePct.toStringAsFixed(0)}%'
                            : '${(_pct(history, 'fake') * 100).toStringAsFixed(0)}%',
                      ),
                      const SizedBox(height: 10),
                      _BarRow(
                        label: 'Real',
                        value: stats != null
                            ? stats.realPct / 100
                            : _pct(history, 'real'),
                        color: AppColors.verdictReal,
                        pctText: stats != null
                            ? '${stats.realPct.toStringAsFixed(0)}%'
                            : '${(_pct(history, 'real') * 100).toStringAsFixed(0)}%',
                      ),
                      const SizedBox(height: 10),
                      _BarRow(
                        label: 'Unsure',
                        value: _pct(history, 'uncertain'),
                        color: AppColors.verdictUncertain,
                        pctText:
                            '${(_pct(history, 'uncertain') * 100).toStringAsFixed(0)}%',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // ── Top sources ──────────────────────────────────────────
                if (history.isNotEmpty)
                  _SectionCard(
                    title: 'Top checked sources',
                    child: Column(
                      children: _topSources(history)
                          .map((e) => _SourceRow(
                              domain: e.key, count: e.value))
                          .toList(),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  double _pct(List<DetectionResult> h, String verdict) {
    if (h.isEmpty) return 0;
    return h.where((r) => r.verdict == verdict).length / h.length;
  }

  List<MapEntry<String, int>> _topSources(List<DetectionResult> h) {
    final counts = <String, int>{};
    for (final r in h) {
      if (r.domain != null) counts[r.domain!] = (counts[r.domain!] ?? 0) + 1;
    }
    final sorted = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(5).toList();
  }
}

// ── Subwidgets ─────────────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title.toUpperCase(),
              style: const TextStyle(
                  fontSize: 10,
                  color: AppColors.textHint,
                  letterSpacing: 0.8)),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String value;
  final String label;
  final Color color;
  const _StatBox(
      {required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value,
              style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                  color: color)),
          const SizedBox(height: 4),
          Text(label,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textHint)),
        ],
      ),
    );
  }
}

class _BarRow extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final String pctText;
  const _BarRow(
      {required this.label,
      required this.value,
      required this.color,
      required this.pctText});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 48,
          child: Text(label,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textSecondary)),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: value.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: AppColors.border,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 38,
          child: Text(pctText,
              textAlign: TextAlign.right,
              style: TextStyle(
                  fontSize: 12,
                  color: color,
                  fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }
}

class _SourceRow extends StatelessWidget {
  final String domain;
  final int count;
  const _SourceRow({required this.domain, required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Container(
            width: 7, height: 7,
            decoration: const BoxDecoration(
                color: AppColors.primary, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(domain,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
          ),
          Text('$count check${count > 1 ? 's' : ''}',
              style: const TextStyle(
                  color: AppColors.textHint, fontSize: 12)),
        ],
      ),
    );
  }
}

class _VerdictPieChart extends StatelessWidget {
  final List<DetectionResult> history;
  const _VerdictPieChart({required this.history});

  @override
  Widget build(BuildContext context) {
    final fake     = history.where((r) => r.verdict == 'fake').length;
    final real     = history.where((r) => r.verdict == 'real').length;
    final uncertain = history.where((r) => r.verdict == 'uncertain').length;
    final total    = history.length.toDouble();

    return Row(
      children: [
        Expanded(
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 40,
              sections: [
                if (fake > 0)
                  PieChartSectionData(
                    value: fake / total * 100,
                    color: AppColors.verdictFake,
                    radius: 28,
                    title: '',
                  ),
                if (real > 0)
                  PieChartSectionData(
                    value: real / total * 100,
                    color: AppColors.verdictReal,
                    radius: 28,
                    title: '',
                  ),
                if (uncertain > 0)
                  PieChartSectionData(
                    value: uncertain / total * 100,
                    color: AppColors.verdictUncertain,
                    radius: 28,
                    title: '',
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 16),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Legend(AppColors.verdictFake, 'Fake', fake),
            const SizedBox(height: 10),
            _Legend(AppColors.verdictReal, 'Real', real),
            const SizedBox(height: 10),
            _Legend(AppColors.verdictUncertain, 'Uncertain', uncertain),
          ],
        ),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  final int count;
  const _Legend(this.color, this.label, this.count);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10, height: 10,
          decoration: BoxDecoration(
              color: color, borderRadius: BorderRadius.circular(3)),
        ),
        const SizedBox(width: 8),
        Text('$label ($count)',
            style: const TextStyle(
                color: AppColors.textSecondary, fontSize: 12)),
      ],
    );
  }
}
