// lib/services/auth_service.dart

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_service.dart';

class AuthService extends ChangeNotifier {
  final ApiService _api;
  final _storage = const FlutterSecureStorage();

  String? _token;
  String? _username;

  bool get isLoggedIn => _token != null;
  String? get username => _username;

  AuthService(this._api) {
    _loadToken();
  }

  Future<void> _loadToken() async {
    _token    = await _storage.read(key: 'auth_token');
    _username = await _storage.read(key: 'username');
    if (_token != null) _api.setToken(_token!);
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    final res = await _api.login(email: email, password: password);
    await _persist(res['token'], res['username'] ?? '');
  }

  Future<void> register(String email, String username, String password) async {
    final res = await _api.register(
        email: email, username: username, password: password);
    await _persist(res['token'], username);
  }

  Future<void> logout() async {
    _token    = null;
    _username = null;
    _api.clearToken();
    await _storage.deleteAll();
    notifyListeners();
  }

  Future<void> _persist(String token, String username) async {
    _token    = token;
    _username = username;
    _api.setToken(token);
    await _storage.write(key: 'auth_token', value: token);
    await _storage.write(key: 'username', value: username);
    notifyListeners();
  }
}


// lib/services/history_service.dart — put in separate file in practice
