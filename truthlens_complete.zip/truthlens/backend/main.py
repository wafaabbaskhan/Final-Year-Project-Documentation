# ============================================================
#  TruthLens — FastAPI Backend
#  main.py
# ============================================================

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, HttpUrl
from typing import Optional
import uvicorn

from database import get_db, SessionLocal
from models import NewsArticle, DetectionResult, DetectionSignal, ArticleTag, SourceMetadata, User
from services.detector import FakeNewsDetector
from services.extractor import ArticleExtractor
from services.auth import verify_token, create_token, hash_password, verify_password
from sqlalchemy.orm import Session
import datetime

app = FastAPI(
    title="TruthLens API",
    description="AI-powered fake news detection backend",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # restrict in production
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer(auto_error=False)
detector  = FakeNewsDetector()
extractor = ArticleExtractor()


# ─── Auth helpers ─────────────────────────────────────────────────────────────

def get_current_user(
    creds: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db)
) -> Optional[User]:
    if creds is None:
        return None
    return verify_token(creds.credentials, db)


# ─── Pydantic schemas ─────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

class TextSubmission(BaseModel):
    text: str
    title: Optional[str] = None

class URLSubmission(BaseModel):
    url: str

class DetectionResponse(BaseModel):
    article_id: int
    result_id: int
    verdict: str                  # "fake" | "real" | "uncertain"
    fake_probability: float       # 0–1
    real_probability: float       # 0–1
    confidence_score: float       # 0–1
    signals: list
    source: dict
    tags: list[str]
    processing_time_ms: int


# ─── Auth routes ──────────────────────────────────────────────────────────────

@app.post("/auth/register", tags=["auth"])
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(400, "Email already registered")
    user = User(
        email=req.email,
        username=req.username,
        password_hash=hash_password(req.password)
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": "Registered successfully", "token": create_token(user.id)}


@app.post("/auth/login", tags=["auth"])
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")
    return {"token": create_token(user.id), "username": user.username}


# ─── News submission routes ───────────────────────────────────────────────────

@app.post("/api/verify/text", response_model=DetectionResponse, tags=["verify"])
def verify_text(
    submission: TextSubmission,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_current_user)
):
    """Submit raw article text for fake-news detection."""
    import time
    start = time.time()

    # Save article
    article = NewsArticle(
        user_id=user.id if user else None,
        submission_type="text",
        title=submission.title,
        body_text=submission.text,
        language="en"
    )
    db.add(article)
    db.commit()
    db.refresh(article)

    # Run AI detection
    analysis = detector.analyze(submission.text, title=submission.title)
    ms = int((time.time() - start) * 1000)

    return _save_and_respond(db, article, analysis, ms)


@app.post("/api/verify/url", response_model=DetectionResponse, tags=["verify"])
def verify_url(
    submission: URLSubmission,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_current_user)
):
    """Submit a news article URL for fake-news detection."""
    import time
    from urllib.parse import urlparse
    start = time.time()

    # Extract content from URL
    extracted = extractor.extract(submission.url)
    if not extracted:
        raise HTTPException(422, "Could not extract content from URL")

    domain = urlparse(submission.url).netloc.replace("www.", "")

    article = NewsArticle(
        user_id=user.id if user else None,
        submission_type="url",
        source_url=submission.url,
        domain=domain,
        title=extracted.get("title"),
        body_text=extracted.get("text"),
        author=extracted.get("author"),
        published_at=extracted.get("published_at"),
        language="en"
    )
    db.add(article)
    db.commit()
    db.refresh(article)

    analysis = detector.analyze(
        extracted.get("text", ""),
        title=extracted.get("title"),
        domain=domain
    )
    ms = int((time.time() - start) * 1000)

    return _save_and_respond(db, article, analysis, ms)


# ─── Results & history routes ─────────────────────────────────────────────────

@app.get("/api/results/{result_id}", tags=["results"])
def get_result(result_id: int, db: Session = Depends(get_db)):
    result = db.query(DetectionResult).filter(DetectionResult.id == result_id).first()
    if not result:
        raise HTTPException(404, "Result not found")
    return _format_result(db, result)


@app.get("/api/history", tags=["results"])
def get_history(
    limit: int = 20,
    offset: int = 0,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_current_user)
):
    """Return paginated verification history for the current user."""
    if not user:
        raise HTTPException(401, "Login required")

    results = (
        db.query(DetectionResult)
        .join(NewsArticle)
        .filter(NewsArticle.user_id == user.id)
        .order_by(DetectionResult.analyzed_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return [_format_result(db, r) for r in results]


@app.get("/api/stats", tags=["results"])
def get_stats(
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_current_user)
):
    """Return aggregate stats for the current user."""
    if not user:
        raise HTTPException(401, "Login required")

    articles = db.query(NewsArticle).filter(NewsArticle.user_id == user.id).all()
    article_ids = [a.id for a in articles]
    results = db.query(DetectionResult).filter(
        DetectionResult.article_id.in_(article_ids)
    ).all() if article_ids else []

    total = len(results)
    fake  = sum(1 for r in results if r.verdict == "fake")
    real  = sum(1 for r in results if r.verdict == "real")
    unc   = sum(1 for r in results if r.verdict == "uncertain")

    return {
        "total_verified": total,
        "total_fake": fake,
        "total_real": real,
        "total_uncertain": unc,
        "fake_pct": round(fake / total * 100, 1) if total else 0,
        "real_pct": round(real / total * 100, 1) if total else 0,
    }


@app.get("/api/source/{domain}", tags=["sources"])
def get_source(domain: str, db: Session = Depends(get_db)):
    src = db.query(SourceMetadata).filter(SourceMetadata.domain == domain).first()
    if not src:
        raise HTTPException(404, "Source not found")
    return {
        "domain": src.domain,
        "display_name": src.display_name,
        "category": src.category,
        "credibility_score": float(src.credibility_score),
        "credibility_label": src.credibility_label,
        "known_misinformation": bool(src.known_misinformation),
    }


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "version": "1.0.0"}


# ─── Internal helpers ─────────────────────────────────────────────────────────

def _save_and_respond(db, article, analysis, ms):
    result = DetectionResult(
        article_id=article.id,
        model_version=analysis["model_version"],
        verdict=analysis["verdict"],
        fake_probability=analysis["fake_probability"],
        real_probability=analysis["real_probability"],
        confidence_score=analysis["confidence_score"],
        processing_time_ms=ms
    )
    db.add(result)
    db.flush()

    for sig in analysis.get("signals", []):
        db.add(DetectionSignal(
            result_id=result.id,
            signal_type=sig["type"],
            label=sig["label"],
            weight=sig["weight"],
            direction=sig["direction"]
        ))

    for tag in analysis.get("tags", []):
        db.add(ArticleTag(article_id=article.id, tag=tag))

    db.commit()
    db.refresh(result)
    return _format_result(db, result)


def _format_result(db, result):
    article = db.query(NewsArticle).filter(NewsArticle.id == result.article_id).first()
    signals = db.query(DetectionSignal).filter(DetectionSignal.result_id == result.id).all()
    tags    = db.query(ArticleTag).filter(ArticleTag.article_id == article.id).all()

    source = {}
    if article.domain:
        src = db.query(SourceMetadata).filter(SourceMetadata.domain == article.domain).first()
        if src:
            source = {
                "domain": src.domain,
                "display_name": src.display_name,
                "credibility_label": src.credibility_label,
                "credibility_score": float(src.credibility_score),
                "category": src.category,
                "known_misinformation": bool(src.known_misinformation)
            }

    return {
        "article_id": article.id,
        "result_id": result.id,
        "title": article.title,
        "domain": article.domain,
        "verdict": result.verdict,
        "fake_probability": float(result.fake_probability),
        "real_probability": float(result.real_probability),
        "confidence_score": float(result.confidence_score),
        "signals": [
            {"label": s.label, "weight": float(s.weight), "direction": s.direction}
            for s in signals
        ],
        "source": source,
        "tags": [t.tag for t in tags],
        "processing_time_ms": result.processing_time_ms,
        "analyzed_at": result.analyzed_at.isoformat()
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
