// lib/theme.dart

import 'package:flutter/material.dart';

class AppColors {
  static const background   = Color(0xFF0F1117);
  static const surface      = Color(0xFF1A1A2E);
  static const surfaceLight = Color(0xFF1E1E2E);
  static const border       = Color(0xFF2A2A3A);
  static const primary      = Color(0xFF6C63FF);
  static const primaryDark  = Color(0xFF5651D8);
  static const accent       = Color(0xFF48CFAD);
  static const textPrimary  = Color(0xFFE0E0F0);
  static const textSecondary = Color(0xFF888898);
  static const textHint     = Color(0xFF444455);

  static const verdictFake  = Color(0xFFEF5350);
  static const verdictReal  = Color(0xFF26A69A);
  static const verdictUncertain = Color(0xFFFFA726);

  static const fakeBg       = Color(0x1AEF5350);  // 10 % opacity
  static const realBg       = Color(0x1A26A69A);
  static const uncertainBg  = Color(0x1AFFA726);
}

class AppTheme {
  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.background,
      primaryColor: AppColors.primary,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.accent,
        surface: AppColors.surface,
        background: AppColors.background,
      ),
      fontFamily: 'SF Pro Display',   // falls back to system sans-serif
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
        titleTextStyle: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w500,
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textHint,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceLight,
        hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
        ),
      ),
    );
  }
}
