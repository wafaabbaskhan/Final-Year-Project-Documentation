// lib/models/detection_result.dart

class DetectionResult {
  final int articleId;
  final int resultId;
  final String? title;
  final String? domain;
  final String verdict;        // "fake" | "real" | "uncertain"
  final double fakeProbability;
  final double realProbability;
  final double confidenceScore;
  final List<DetectionSignal> signals;
  final SourceInfo? source;
  final List<String> tags;
  final int processingTimeMs;
  final DateTime analyzedAt;

  const DetectionResult({
    required this.articleId,
    required this.resultId,
    this.title,
    this.domain,
    required this.verdict,
    required this.fakeProbability,
    required this.realProbability,
    required this.confidenceScore,
    required this.signals,
    this.source,
    required this.tags,
    required this.processingTimeMs,
    required this.analyzedAt,
  });

  factory DetectionResult.fromJson(Map<String, dynamic> j) => DetectionResult(
        articleId: j['article_id'],
        resultId: j['result_id'],
        title: j['title'],
        domain: j['domain'],
        verdict: j['verdict'],
        fakeProbability: (j['fake_probability'] as num).toDouble(),
        realProbability: (j['real_probability'] as num).toDouble(),
        confidenceScore: (j['confidence_score'] as num).toDouble(),
        signals: (j['signals'] as List)
            .map((s) => DetectionSignal.fromJson(s))
            .toList(),
        source: j['source'] != null && (j['source'] as Map).isNotEmpty
            ? SourceInfo.fromJson(j['source'])
            : null,
        tags: List<String>.from(j['tags'] ?? []),
        processingTimeMs: j['processing_time_ms'] ?? 0,
        analyzedAt: DateTime.parse(j['analyzed_at']),
      );
}

class DetectionSignal {
  final String label;
  final double weight;
  final String direction; // "fake" | "real" | "neutral"

  const DetectionSignal({
    required this.label,
    required this.weight,
    required this.direction,
  });

  factory DetectionSignal.fromJson(Map<String, dynamic> j) => DetectionSignal(
        label: j['label'],
        weight: (j['weight'] as num).toDouble(),
        direction: j['direction'],
      );
}

class SourceInfo {
  final String domain;
  final String? displayName;
  final String? credibilityLabel; // "high" | "medium" | "low" | "unknown"
  final double? credibilityScore;
  final String? category;
  final bool knownMisinformation;

  const SourceInfo({
    required this.domain,
    this.displayName,
    this.credibilityLabel,
    this.credibilityScore,
    this.category,
    required this.knownMisinformation,
  });

  factory SourceInfo.fromJson(Map<String, dynamic> j) => SourceInfo(
        domain: j['domain'],
        displayName: j['display_name'],
        credibilityLabel: j['credibility_label'],
        credibilityScore: (j['credibility_score'] as num?)?.toDouble(),
        category: j['category'],
        knownMisinformation: j['known_misinformation'] ?? false,
      );
}

class UserStats {
  final int totalVerified;
  final int totalFake;
  final int totalReal;
  final int totalUncertain;
  final double fakePct;
  final double realPct;

  const UserStats({
    required this.totalVerified,
    required this.totalFake,
    required this.totalReal,
    required this.totalUncertain,
    required this.fakePct,
    required this.realPct,
  });

  factory UserStats.fromJson(Map<String, dynamic> j) => UserStats(
        totalVerified: j['total_verified'],
        totalFake: j['total_fake'],
        totalReal: j['total_real'],
        totalUncertain: j['total_uncertain'],
        fakePct: (j['fake_pct'] as num).toDouble(),
        realPct: (j['real_pct'] as num).toDouble(),
      );
}
