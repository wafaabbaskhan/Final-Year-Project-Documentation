// lib/screens/history_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/history_service.dart';
import '../models/detection_result.dart';
import 'result_screen.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: Consumer<HistoryService>(
        builder: (_, hs, __) {
          if (hs.loading) {
            return const Center(
                child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (hs.history.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history, color: AppColors.textHint, size: 48),
                  SizedBox(height: 12),
                  Text('No verifications yet',
                      style: TextStyle(
                          color: AppColors.textHint, fontSize: 15)),
                  SizedBox(height: 6),
                  Text('Verified articles will appear here',
                      style: TextStyle(
                          color: AppColors.textHint, fontSize: 12)),
                ],
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: hs.history.length,
            separatorBuilder: (_, __) =>
                const Divider(color: AppColors.surfaceLight, height: 1),
            itemBuilder: (ctx, i) => _HistoryTile(result: hs.history[i]),
          );
        },
      ),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  final DetectionResult result;
  const _HistoryTile({required this.result});

  @override
  Widget build(BuildContext context) {
    Color color;
    IconData icon;
    switch (result.verdict) {
      case 'fake':
        color = AppColors.verdictFake;
        icon  = Icons.warning_amber_outlined;
        break;
      case 'real':
        color = AppColors.verdictReal;
        icon  = Icons.check_circle_outline;
        break;
      default:
        color = AppColors.verdictUncertain;
        icon  = Icons.help_outline;
    }
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 6),
      leading: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(
        result.title ?? result.domain ?? 'Article',
        style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w500),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '${result.domain ?? ''} · ${_timeAgo(result.analyzedAt)}',
        style: const TextStyle(color: AppColors.textHint, fontSize: 11),
      ),
      trailing: const Icon(Icons.chevron_right,
          color: AppColors.border, size: 18),
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => ResultScreen(result: result))),
    );
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24)   return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// lib/screens/stats_screen.dart
// ─────────────────────────────────────────────────────────────────────────────

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Statistics')),
      body: Consumer<HistoryService>(
        builder: (_, hs, __) {
          final stats = hs.stats;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Grid of 4 stat boxes
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.5,
                  children: [
                    _StatBox('${stats?.totalVerified ?? 0}',
                        'Articles verified', AppColors.textPrimary),
                    _StatBox('${stats?.totalFake ?? 0}',
                        'Flagged as fake', AppColors.verdictFake),
                    _StatBox('${stats?.totalReal ?? 0}',
                        'Confirmed real', AppColors.verdictReal),
                    _StatBox('${stats?.totalUncertain ?? 0}',
                        'Uncertain', AppColors.verdictUncertain),
                  ],
                ),
                const SizedBox(height: 16),

                // Bar breakdown
                _section(
                  title: 'Verification breakdown',
                  child: Column(
                    children: [
                      _BarRow('Fake',
                          (stats?.fakePct ?? 0) / 100, AppColors.verdictFake,
                          '${stats?.fakePct.toStringAsFixed(0) ?? 0}%'),
                      const SizedBox(height: 10),
                      _BarRow('Real',
                          (stats?.realPct ?? 0) / 100, AppColors.verdictReal,
                          '${stats?.realPct.toStringAsFixed(0) ?? 0}%'),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _section({required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title.toUpperCase(),
              style: const TextStyle(
                  fontSize: 10, color: AppColors.textHint, letterSpacing: 0.8)),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String value;
  final String label;
  final Color color;
  const _StatBox(this.value, this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value,
              style: TextStyle(
                  fontSize: 24, fontWeight: FontWeight.w500, color: color)),
          const SizedBox(height: 4),
          Text(label,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textHint)),
        ],
      ),
    );
  }
}

class _BarRow extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final String pctText;
  const _BarRow(this.label, this.value, this.color, this.pctText);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 48,
          child: Text(label,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textSecondary)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: value,
              minHeight: 8,
              backgroundColor: AppColors.border,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 36,
          child: Text(pctText,
              textAlign: TextAlign.right,
              style: TextStyle(
                  fontSize: 12, color: color, fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// lib/screens/profile_screen.dart
// ─────────────────────────────────────────────────────────────────────────────

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Avatar row
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.accent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.person, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 14),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('User',
                          style: TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 16,
                              fontWeight: FontWeight.w500)),
                      Text('user@example.com',
                          style: TextStyle(
                              color: AppColors.textHint, fontSize: 12)),
                      SizedBox(height: 2),
                      Text('Free Plan',
                          style: TextStyle(
                              color: AppColors.primary, fontSize: 11)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Settings tiles
            _settingsGroup([
              _SettingsTile(
                  icon: Icons.notifications_outlined, label: 'Notifications'),
              _SettingsTile(
                  icon: Icons.shield_outlined, label: 'Privacy & Security'),
              _SettingsTile(
                  icon: Icons.settings_outlined, label: 'App settings'),
            ]),
            const SizedBox(height: 12),
            _settingsGroup([
              _SettingsTile(
                  icon: Icons.storage_outlined,
                  label: 'API configuration',
                  iconColor: AppColors.accent),
              _SettingsTile(
                  icon: Icons.psychology_outlined,
                  label: 'AI model settings',
                  iconColor: AppColors.accent),
            ]),
            const SizedBox(height: 12),

            // Backend status
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Text('Backend status',
                      style: TextStyle(
                          color: AppColors.textHint, fontSize: 12)),
                  const Spacer(),
                  Container(
                    width: 7, height: 7,
                    decoration: const BoxDecoration(
                        color: AppColors.verdictReal, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  const Text('Connected · FastAPI',
                      style: TextStyle(
                          color: AppColors.verdictReal, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _settingsGroup(List<Widget> tiles) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: tiles
            .asMap()
            .entries
            .map((e) => Column(children: [
                  e.value,
                  if (e.key < tiles.length - 1)
                    const Divider(
                        height: 1, color: AppColors.surfaceLight, indent: 52),
                ]))
            .toList(),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor;
  const _SettingsTile({
    required this.icon,
    required this.label,
    this.iconColor = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      trailing: const Icon(Icons.chevron_right,
          color: AppColors.border, size: 18),
      onTap: () {},
    );
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// lib/screens/splash_screen.dart
// ─────────────────────────────────────────────────────────────────────────────

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primary, AppColors.accent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Icon(Icons.search,
                  color: Colors.white, size: 40),
            ),
            const SizedBox(height: 16),
            const Text('TruthLens',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textPrimary)),
            const SizedBox(height: 8),
            const Text('AI-Powered Fake News Detection',
                style: TextStyle(
                    fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 48),
            const CircularProgressIndicator(
                color: AppColors.primary, strokeWidth: 2),
          ],
        ),
      ),
    );
  }
}
