// lib/screens/result_screen.dart

import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/detection_result.dart';

class ResultScreen extends StatelessWidget {
  final DetectionResult result;
  const ResultScreen({super.key, required this.result});

  Color get _verdictColor => switch (result.verdict) {
        'fake'      => AppColors.verdictFake,
        'real'      => AppColors.verdictReal,
        _           => AppColors.verdictUncertain,
      };

  String get _verdictEmoji => switch (result.verdict) {
        'fake' => '⚠️',
        'real' => '✅',
        _      => '🤔',
      };

  String get _verdictLabel => switch (result.verdict) {
        'fake' => 'Likely Fake',
        'real' => 'Credible News',
        _      => 'Uncertain',
      };

  String get _verdictSub => switch (result.verdict) {
        'fake' => 'High probability of misinformation',
        'real' => 'High probability of authentic reporting',
        _      => 'Insufficient evidence for clear verdict',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detection Report'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ── Big Verdict Card ──────────────────────────────────────
            _card(
              child: Column(
                children: [
                  Text(_verdictEmoji, style: const TextStyle(fontSize: 44)),
                  const SizedBox(height: 8),
                  Text(_verdictLabel,
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          color: _verdictColor)),
                  const SizedBox(height: 4),
                  Text(_verdictSub,
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // ── Confidence Breakdown ──────────────────────────────────
            _card(
              title: 'Confidence breakdown',
              child: Column(
                children: [
                  _gaugeRow('Fake probability',
                      result.fakeProbability, AppColors.verdictFake),
                  const SizedBox(height: 12),
                  _gaugeRow('Real probability',
                      result.realProbability, AppColors.verdictReal),
                  const SizedBox(height: 12),
                  _gaugeRow('Model confidence',
                      result.confidenceScore, AppColors.primary),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // ── Detection Signals ─────────────────────────────────────
            _card(
              title: 'Detection signals',
              child: Column(
                children: result.signals
                    .map((s) => _SignalRow(signal: s))
                    .toList(),
              ),
            ),
            const SizedBox(height: 12),

            // ── Source Credibility ────────────────────────────────────
            if (result.source != null)
              _card(
                title: 'Source credibility',
                child: _SourceCard(source: result.source!),
              ),
            if (result.source != null) const SizedBox(height: 12),

            // ── Tags ──────────────────────────────────────────────────
            if (result.tags.isNotEmpty)
              _card(
                title: 'Content tags',
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: result.tags
                      .map((t) => _chip(t))
                      .toList(),
                ),
              ),
            if (result.tags.isNotEmpty) const SizedBox(height: 16),

            // ── Actions ───────────────────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.shield_outlined, size: 18),
                label: const Text('Verify Another Article'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: OutlinedButton.icon(
                onPressed: () {/* share */},
                icon: const Icon(Icons.share_outlined, size: 16),
                label: const Text('Share Report'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  side: const BorderSide(color: AppColors.primary),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card({String? title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null) ...[
            Text(title.toUpperCase(),
                style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textHint,
                    letterSpacing: 0.8)),
            const SizedBox(height: 12),
          ],
          child,
        ],
      ),
    );
  }

  Widget _gaugeRow(String label, double value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
            const Spacer(),
            Text('${(value * 100).round()}%',
                style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.w500)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: LinearProgressIndicator(
            value: value,
            minHeight: 10,
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }

  Widget _chip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(label,
          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
    );
  }
}

class _SignalRow extends StatelessWidget {
  final DetectionSignal signal;
  const _SignalRow({required this.signal});

  @override
  Widget build(BuildContext context) {
    Color dotColor = switch (signal.direction) {
      'fake'    => AppColors.verdictFake,
      'real'    => AppColors.verdictReal,
      _         => AppColors.verdictUncertain,
    };

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 8, height: 8,
            decoration: BoxDecoration(
                color: dotColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(signal.label,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
          ),
          Text(
            signal.weight >= 0
                ? '+${signal.weight.toInt()}'
                : '${signal.weight.toInt()}',
            style: TextStyle(
                color: signal.weight < 0
                    ? AppColors.verdictFake
                    : AppColors.verdictReal,
                fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _SourceCard extends StatelessWidget {
  final SourceInfo source;
  const _SourceCard({required this.source});

  @override
  Widget build(BuildContext context) {
    Color credColor = switch (source.credibilityLabel) {
      'high'   => AppColors.verdictReal,
      'medium' => AppColors.verdictUncertain,
      _        => AppColors.verdictFake,
    };
    String credLabel =
        (source.credibilityLabel ?? 'Unknown').replaceFirst(
            source.credibilityLabel?[0] ?? '',
            (source.credibilityLabel?[0] ?? '').toUpperCase());

    return Row(
      children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: AppColors.border,
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.language,
              color: AppColors.primary, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(source.displayName ?? source.domain,
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500)),
              if (source.category != null)
                Text(source.category!,
                    style: const TextStyle(
                        color: AppColors.textHint, fontSize: 12)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: credColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(credLabel,
              style: TextStyle(
                  color: credColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }
}
