# models.py — SQLAlchemy ORM models

from sqlalchemy import (
    Column, Integer, BigInteger, String, Text, DateTime,
    Enum, DECIMAL, Boolean, ForeignKey, SmallInteger
)
from sqlalchemy.orm import relationship
from database import Base
import datetime


class User(Base):
    __tablename__ = "users"
    id            = Column(Integer, primary_key=True, index=True)
    email         = Column(String(255), unique=True, nullable=False, index=True)
    username      = Column(String(100), nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_premium    = Column(Boolean, default=False)
    created_at    = Column(DateTime, default=datetime.datetime.utcnow)
    articles      = relationship("NewsArticle", back_populates="user")


class SourceMetadata(Base):
    __tablename__ = "source_metadata"
    id                   = Column(Integer, primary_key=True)
    domain               = Column(String(255), unique=True, nullable=False)
    display_name         = Column(String(255))
    category             = Column(String(100))
    credibility_score    = Column(DECIMAL(5, 2), default=50.0)
    credibility_label    = Column(
        Enum("high", "medium", "low", "unknown"), default="unknown"
    )
    known_misinformation = Column(Boolean, default=False)
    country_code         = Column(String(2))
    notes                = Column(Text)
    last_reviewed_at     = Column(DateTime)
    created_at           = Column(DateTime, default=datetime.datetime.utcnow)


class NewsArticle(Base):
    __tablename__ = "news_articles"
    id              = Column(BigInteger, primary_key=True, index=True)
    user_id         = Column(Integer, ForeignKey("users.id"), nullable=True)
    submission_type = Column(Enum("url", "text"), nullable=False)
    source_url      = Column(String(2048))
    domain          = Column(String(255), index=True)
    title           = Column(String(1000))
    body_text       = Column(Text)
    author          = Column(String(255))
    published_at    = Column(DateTime)
    language        = Column(String(5), default="en")
    submitted_at    = Column(DateTime, default=datetime.datetime.utcnow)

    user    = relationship("User", back_populates="articles")
    result  = relationship("DetectionResult", back_populates="article", uselist=False)
    tags    = relationship("ArticleTag", back_populates="article")


class DetectionResult(Base):
    __tablename__ = "detection_results"
    id                 = Column(BigInteger, primary_key=True, index=True)
    article_id         = Column(BigInteger, ForeignKey("news_articles.id"), nullable=False)
    model_version      = Column(String(50), default="v1.0")
    verdict            = Column(Enum("fake", "real", "uncertain"), nullable=False)
    fake_probability   = Column(DECIMAL(5, 4), nullable=False)
    real_probability   = Column(DECIMAL(5, 4), nullable=False)
    confidence_score   = Column(DECIMAL(5, 4), nullable=False)
    processing_time_ms = Column(Integer)
    analyzed_at        = Column(DateTime, default=datetime.datetime.utcnow)

    article = relationship("NewsArticle", back_populates="result")
    signals = relationship("DetectionSignal", back_populates="result")


class DetectionSignal(Base):
    __tablename__ = "detection_signals"
    id          = Column(BigInteger, primary_key=True)
    result_id   = Column(BigInteger, ForeignKey("detection_results.id"), nullable=False)
    signal_type = Column(String(100), nullable=False)
    label       = Column(String(255), nullable=False)
    weight      = Column(DECIMAL(6, 2), nullable=False)
    direction   = Column(Enum("fake", "real", "neutral"), nullable=False)

    result = relationship("DetectionResult", back_populates="signals")


class ArticleTag(Base):
    __tablename__ = "article_tags"
    article_id = Column(BigInteger, ForeignKey("news_articles.id"), primary_key=True)
    tag        = Column(String(100), primary_key=True)

    article = relationship("NewsArticle", back_populates="tags")
