// lib/screens/verify_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/api_service.dart';
import '../services/history_service.dart';
import '../models/detection_result.dart';
import 'result_screen.dart';

class VerifyScreen extends StatefulWidget {
  const VerifyScreen({super.key});
  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _textCtrl = TextEditingController();
  final _urlCtrl  = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _textCtrl.dispose();
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    final isText = _tabController.index == 0;
    final input  = isText ? _textCtrl.text.trim() : _urlCtrl.text.trim();

    if (input.isEmpty) {
      setState(() => _error = 'Please enter ${isText ? 'article text' : 'a URL'}');
      return;
    }

    setState(() { _loading = true; _error = null; });

    try {
      final api = context.read<ApiService>();
      final result = isText
          ? await api.verifyText(text: input)
          : await api.verifyUrl(input);

      if (!mounted) return;
      context.read<HistoryService>().addResult(result);

      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ResultScreen(result: result)),
      );
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header ───────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.accent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.search, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('TruthLens',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: AppColors.textPrimary)),
                      Text('AI-Powered News Verifier',
                          style: TextStyle(
                              fontSize: 11, color: AppColors.textHint)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // ── Tab toggle ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.surfaceLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(4),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: AppColors.textHint,
                  labelStyle: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w500),
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(icon: Icon(Icons.article_outlined, size: 16), text: 'Text'),
                    Tab(icon: Icon(Icons.link, size: 16), text: 'URL'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Input area ────────────────────────────────────────────
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    SizedBox(
                      height: 200,
                      child: TabBarView(
                        controller: _tabController,
                        children: [
                          // Text tab
                          Container(
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppColors.border),
                            ),
                            padding: const EdgeInsets.all(14),
                            child: TextField(
                              controller: _textCtrl,
                              maxLines: null,
                              expands: true,
                              style: const TextStyle(
                                  color: AppColors.textPrimary, fontSize: 14),
                              decoration: const InputDecoration(
                                hintText:
                                    'Paste news article text here to verify its authenticity…',
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ),
                          // URL tab
                          Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  color: AppColors.surfaceLight,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: AppColors.border),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 4),
                                child: Row(
                                  children: [
                                    const Icon(Icons.language,
                                        color: AppColors.textHint, size: 18),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: TextField(
                                        controller: _urlCtrl,
                                        style: const TextStyle(
                                            color: AppColors.textPrimary,
                                            fontSize: 13),
                                        decoration: const InputDecoration(
                                          hintText:
                                              'https://example.com/news-article',
                                          border: InputBorder.none,
                                          contentPadding: EdgeInsets.zero,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text('Supports most major news platforms',
                                  style: TextStyle(
                                      fontSize: 11, color: AppColors.textHint)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Error
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(_error!,
                            style: const TextStyle(
                                color: AppColors.verdictFake, fontSize: 13)),
                      ),

                    // Verify button
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _loading ? null : _verify,
                        icon: _loading
                            ? const SizedBox(
                                width: 18, height: 18,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2))
                            : const Icon(Icons.shield_outlined, size: 18),
                        label: Text(_loading ? 'Analyzing…' : 'Verify Now'),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Recent verifications label
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('RECENT VERIFICATIONS',
                          style: TextStyle(
                              fontSize: 10,
                              color: AppColors.textHint,
                              letterSpacing: 0.8)),
                    ),
                    const SizedBox(height: 10),

                    // Sample cards from history
                    Consumer<HistoryService>(
                      builder: (_, hs, __) {
                        final items = hs.history.take(3).toList();
                        if (items.isEmpty) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(24),
                              child: Text('No verifications yet',
                                  style: TextStyle(
                                      color: AppColors.textHint, fontSize: 13)),
                            ),
                          );
                        }
                        return Column(
                          children: items
                              .map((r) => _ResultCard(result: r))
                              .toList(),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final DetectionResult result;
  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    IconData icon;
    switch (result.verdict) {
      case 'fake':
        color = AppColors.verdictFake;
        label = 'Likely Fake';
        icon  = Icons.warning_amber_outlined;
        break;
      case 'real':
        color = AppColors.verdictReal;
        label = 'Credible';
        icon  = Icons.check_circle_outline;
        break;
      default:
        color = AppColors.verdictUncertain;
        label = 'Uncertain';
        icon  = Icons.help_outline;
    }
    final pct = result.verdict == 'fake'
        ? result.fakeProbability
        : result.realProbability;

    return GestureDetector(
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => ResultScreen(result: result))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badge row
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, size: 12, color: color),
                      const SizedBox(width: 4),
                      Text(label,
                          style: TextStyle(
                              fontSize: 11,
                              color: color,
                              fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // Title
            Text(
              result.title ?? result.domain ?? 'Article',
              style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            // Meta + pct
            Row(
              children: [
                Text(result.domain ?? 'Unknown source',
                    style: const TextStyle(
                        color: AppColors.textHint, fontSize: 11)),
                const Spacer(),
                Text('${(pct * 100).round()}%',
                    style: TextStyle(
                        color: color, fontSize: 12, fontWeight: FontWeight.w500)),
              ],
            ),
            const SizedBox(height: 6),
            // Bar
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: pct,
                minHeight: 5,
                backgroundColor: AppColors.border,
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
