// lib/screens/profile_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ── Avatar / user info ───────────────────────────────────
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(
                    width: 54, height: 54,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.accent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.person,
                        color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        auth.isLoggedIn
                            ? (auth.username ?? 'User')
                            : 'Guest',
                        style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w500),
                      ),
                      const Text('user@example.com',
                          style: TextStyle(
                              color: AppColors.textHint, fontSize: 12)),
                      const SizedBox(height: 2),
                      const Text('Free Plan',
                          style: TextStyle(
                              color: AppColors.primary, fontSize: 11)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // ── App settings group ───────────────────────────────────
            _SettingsGroup(tiles: [
              _SettingsTile(
                icon: Icons.notifications_outlined,
                label: 'Notifications',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.lock_outline,
                label: 'Privacy & Security',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.settings_outlined,
                label: 'App settings',
                onTap: () {},
              ),
            ]),
            const SizedBox(height: 12),

            // ── Developer settings group ─────────────────────────────
            _SettingsGroup(tiles: [
              _SettingsTile(
                icon: Icons.storage_outlined,
                label: 'API configuration',
                iconColor: AppColors.accent,
                onTap: () => _showApiConfig(context),
              ),
              _SettingsTile(
                icon: Icons.psychology_outlined,
                label: 'AI model settings',
                iconColor: AppColors.accent,
                onTap: () {},
              ),
            ]),
            const SizedBox(height: 12),

            // ── Backend status ───────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Text('Backend status',
                      style: TextStyle(
                          color: AppColors.textHint, fontSize: 12)),
                  const Spacer(),
                  Container(
                    width: 7, height: 7,
                    decoration: const BoxDecoration(
                        color: AppColors.verdictReal,
                        shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  const Text('Connected · FastAPI',
                      style: TextStyle(
                          color: AppColors.verdictReal, fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ── Logout / Login button ────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 48,
              child: auth.isLoggedIn
                  ? OutlinedButton.icon(
                      onPressed: () async {
                        await auth.logout();
                        if (context.mounted) {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const LoginScreen()),
                            (_) => false,
                          );
                        }
                      },
                      icon: const Icon(Icons.logout, size: 17),
                      label: const Text('Log out'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.verdictFake,
                        side: const BorderSide(
                            color: AppColors.verdictFake),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                    )
                  : ElevatedButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const LoginScreen()),
                      ),
                      icon: const Icon(Icons.login, size: 17),
                      label: const Text('Log in'),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showApiConfig(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('API Configuration',
                style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 17,
                    fontWeight: FontWeight.w500)),
            const SizedBox(height: 16),
            const Text('Base URL',
                style: TextStyle(
                    color: AppColors.textHint, fontSize: 12)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surfaceLight,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: const Text('http://10.0.2.2:8000',
                  style: TextStyle(
                      color: AppColors.textPrimary, fontSize: 13)),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ── Shared widgets ─────────────────────────────────────────────────────────

class _SettingsGroup extends StatelessWidget {
  final List<_SettingsTile> tiles;
  const _SettingsGroup({required this.tiles});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: tiles.asMap().entries.map((e) {
          return Column(
            children: [
              e.value,
              if (e.key < tiles.length - 1)
                const Divider(
                    height: 1,
                    color: AppColors.surfaceLight,
                    indent: 52),
            ],
          );
        }).toList(),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color iconColor;

  const _SettingsTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.iconColor = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      trailing: const Icon(Icons.chevron_right,
          color: AppColors.border, size: 18),
      onTap: onTap,
    );
  }
}
