# TruthLens — AI Fake News Detection App

A full-stack fake news detection system with:
- **Flutter** cross-platform mobile app (iOS + Android)
- **FastAPI** RESTful backend
- **MySQL** database
- **AI detection** via Anthropic Claude (LLM) + rule-based NLP

---

## Project Structure

```
truthlens/
├── flutter/               # Flutter mobile app
│   ├── pubspec.yaml
│   └── lib/
│       ├── main.dart
│       ├── theme.dart
│       ├── models/
│       │   └── detection_result.dart
│       ├── services/
│       │   ├── api_service.dart
│       │   ├── auth_service.dart
│       │   └── history_service.dart
│       └── screens/
│           ├── splash_screen.dart
│           ├── home_screen.dart
│           ├── verify_screen.dart
│           ├── result_screen.dart
│           ├── history_screen.dart
│           ├── stats_screen.dart
│           ├── profile_screen.dart
│           └── login_screen.dart
├── backend/               # FastAPI backend
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── requirements.txt
│   ├── .env.example
│   └── services/
│       ├── detector.py    # AI fake news engine
│       ├── extractor.py   # URL article scraper
│       └── auth.py        # JWT authentication
└── database/
    └── schema.sql         # MySQL schema + seed data
```

---

## Quick Start

### 1. Database Setup

```bash
mysql -u root -p < database/schema.sql
```

### 2. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env — add your DATABASE_URL and ANTHROPIC_API_KEY

uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

API docs available at: `http://localhost:8000/docs`

### 3. Flutter App Setup

```bash
cd flutter
flutter pub get

# Android emulator (uses 10.0.2.2 to reach localhost)
flutter run

# For a real device, update _base in lib/services/api_service.dart
# to your machine's local IP, e.g. http://192.168.1.10:8000
```

---

## API Endpoints

| Method | Endpoint             | Description                        |
|--------|---------------------|------------------------------------|
| POST   | /auth/register      | Create new user account            |
| POST   | /auth/login         | Login and get JWT token            |
| POST   | /api/verify/text    | Verify news by raw text            |
| POST   | /api/verify/url     | Verify news by URL                 |
| GET    | /api/results/{id}   | Get a specific detection result    |
| GET    | /api/history        | Get user's verification history    |
| GET    | /api/stats          | Get user's aggregate statistics    |
| GET    | /api/source/{domain}| Get source credibility info        |
| GET    | /health             | Backend health check               |

---

## Detection Engine

The AI engine uses a **two-stage pipeline**:

**Stage 1 — Rule-based NLP (fast, 30% weight)**
- Sensationalist language detection
- ALL CAPS excessive usage
- Punctuation abuse (`!!!`, `???`)
- Attributed quotes check
- External references / links
- Named entity detection

**Stage 2 — LLM Classification (nuanced, 70% weight)**
- Sends article text to Claude Sonnet
- Returns fake probability (0.0–1.0)
- Detects: emotional manipulation, conspiracy claims, lack of evidence
- Generates content tags

**Verdict thresholds:**
- `fake_probability >= 0.65` → **Fake**
- `fake_probability <= 0.40` → **Real**
- Between 0.40–0.65 → **Uncertain**

---

## Flutter App Features

| Screen  | Features |
|---------|----------|
| Verify  | Text input, URL input, toggle between modes, recent results |
| Result  | Verdict badge, confidence bars, signal breakdown, source credibility, tags |
| History | Searchable list, grouped by date, tap to view full report |
| Stats   | 4-box summary, pie chart, bar breakdown, top sources |
| Profile | User info, settings, API config, backend status, logout |

---

## Environment Variables

| Variable          | Description                          |
|-------------------|--------------------------------------|
| `DATABASE_URL`    | MySQL connection string              |
| `ANTHROPIC_API_KEY` | Your Anthropic API key             |
| `SECRET_KEY`      | JWT signing secret (keep private!)   |

---

## Production Checklist

- [ ] Change `SECRET_KEY` to a long random value
- [ ] Set `CORS` origins to your app's domain only
- [ ] Use HTTPS (add SSL to FastAPI via nginx)
- [ ] Update `_base` URL in `api_service.dart` to production URL
- [ ] Enable `echo=False` in SQLAlchemy (already set)
- [ ] Add rate limiting to `/api/verify/*` endpoints
- [ ] Set up database backups
