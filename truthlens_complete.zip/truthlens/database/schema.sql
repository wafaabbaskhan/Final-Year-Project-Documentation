-- ============================================================
--  TruthLens — MySQL Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS truthlens CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE truthlens;

-- ------------------------------------------------------------
-- 1. Users
-- ------------------------------------------------------------
CREATE TABLE users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email         VARCHAR(255) NOT NULL UNIQUE,
    username      VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_premium    TINYINT(1)   NOT NULL DEFAULT 0,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. Source Metadata  (known domains + credibility scores)
-- ------------------------------------------------------------
CREATE TABLE source_metadata (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    domain            VARCHAR(255) NOT NULL UNIQUE,
    display_name      VARCHAR(255),
    category          VARCHAR(100),           -- e.g. "International News", "Satire", "Clickbait"
    credibility_score DECIMAL(5,2) DEFAULT 50.00,  -- 0-100
    credibility_label ENUM('high','medium','low','unknown') DEFAULT 'unknown',
    known_misinformation TINYINT(1) DEFAULT 0,
    country_code      CHAR(2),
    notes             TEXT,
    last_reviewed_at  DATETIME,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_domain (domain),
    INDEX idx_credibility (credibility_label)
) ENGINE=InnoDB;

-- Pre-populate a few well-known sources
INSERT INTO source_metadata (domain, display_name, category, credibility_score, credibility_label) VALUES
('reuters.com',  'Reuters',       'International News', 95.0, 'high'),
('bbc.co.uk',    'BBC News',      'International News', 94.0, 'high'),
('apnews.com',   'AP News',       'International News', 95.0, 'high'),
('dawn.com',     'Dawn',          'Pakistan News',      88.0, 'high'),
('geo.tv',       'Geo News',      'Pakistan News',      75.0, 'medium'),
('infowire.net', 'InfoWire',      'Satire/Clickbait',   12.0, 'low'),
('viralpost.xyz','ViralPost',     'Clickbait',           8.0, 'low'),
('healthnews.io','HealthNews',    'Health',             45.0, 'medium');

-- ------------------------------------------------------------
-- 3. News Articles  (user-submitted content)
-- ------------------------------------------------------------
CREATE TABLE news_articles (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED,
    submission_type ENUM('url','text') NOT NULL,
    source_url     VARCHAR(2048),
    domain         VARCHAR(255),
    title          VARCHAR(1000),
    body_text      MEDIUMTEXT,
    author         VARCHAR(255),
    published_at   DATETIME,
    language       CHAR(5) DEFAULT 'en',
    submitted_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user    (user_id),
    INDEX idx_domain  (domain),
    INDEX idx_submitted (submitted_at),
    FULLTEXT INDEX ft_body (title, body_text)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. Detection Results
-- ------------------------------------------------------------
CREATE TABLE detection_results (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    article_id          BIGINT UNSIGNED NOT NULL,
    model_version       VARCHAR(50) NOT NULL DEFAULT 'v1.0',
    verdict             ENUM('fake','real','uncertain') NOT NULL,
    fake_probability    DECIMAL(5,4) NOT NULL,   -- 0.0000 – 1.0000
    real_probability    DECIMAL(5,4) NOT NULL,
    confidence_score    DECIMAL(5,4) NOT NULL,   -- overall model confidence
    processing_time_ms  INT UNSIGNED,
    analyzed_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES news_articles(id) ON DELETE CASCADE,
    INDEX idx_article  (article_id),
    INDEX idx_verdict  (verdict),
    INDEX idx_analyzed (analyzed_at)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. Detection Signals  (per-result NLP flags)
-- ------------------------------------------------------------
CREATE TABLE detection_signals (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    result_id     BIGINT UNSIGNED NOT NULL,
    signal_type   VARCHAR(100) NOT NULL,   -- e.g. "sensationalist_language"
    label         VARCHAR(255) NOT NULL,   -- human-readable label
    weight        DECIMAL(6,2) NOT NULL,   -- negative = fake indicator, positive = real
    direction     ENUM('fake','real','neutral') NOT NULL,
    FOREIGN KEY (result_id) REFERENCES detection_results(id) ON DELETE CASCADE,
    INDEX idx_result (result_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. Content Tags  (keywords / topics per article)
-- ------------------------------------------------------------
CREATE TABLE article_tags (
    article_id BIGINT UNSIGNED NOT NULL,
    tag        VARCHAR(100)   NOT NULL,
    PRIMARY KEY (article_id, tag),
    FOREIGN KEY (article_id) REFERENCES news_articles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 7. Useful views
-- ------------------------------------------------------------

-- Full result with article info and source credibility
CREATE OR REPLACE VIEW v_full_results AS
SELECT
    dr.id                  AS result_id,
    na.id                  AS article_id,
    na.user_id,
    na.submission_type,
    na.source_url,
    na.domain,
    na.title,
    na.submitted_at,
    dr.verdict,
    dr.fake_probability,
    dr.real_probability,
    dr.confidence_score,
    dr.analyzed_at,
    sm.display_name        AS source_display_name,
    sm.credibility_score,
    sm.credibility_label,
    sm.category            AS source_category,
    sm.known_misinformation
FROM detection_results dr
JOIN news_articles      na ON na.id = dr.article_id
LEFT JOIN source_metadata sm ON sm.domain = na.domain;

-- User stats summary
CREATE OR REPLACE VIEW v_user_stats AS
SELECT
    na.user_id,
    COUNT(*)                                           AS total_verified,
    SUM(dr.verdict = 'fake')                           AS total_fake,
    SUM(dr.verdict = 'real')                           AS total_real,
    SUM(dr.verdict = 'uncertain')                      AS total_uncertain,
    ROUND(AVG(dr.confidence_score) * 100, 1)           AS avg_confidence_pct,
    MAX(dr.analyzed_at)                                AS last_activity
FROM detection_results dr
JOIN news_articles na ON na.id = dr.article_id
GROUP BY na.user_id;
