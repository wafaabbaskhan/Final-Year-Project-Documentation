// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/detection_result.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});
  @override
  String toString() => message;
}

class ApiService {
  // Change to your server IP / domain in production
  static const String _base = 'http://10.0.2.2:8000'; // Android emulator localhost

  String? _token;
  void setToken(String token) => _token = token;
  void clearToken() => _token = null;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  // ── Auth ─────────────────────────────────────────────────────────────────

  Future<Map<String, dynamic>> register({
    required String email,
    required String username,
    required String password,
  }) async {
    return _post('/auth/register', {
      'email': email,
      'username': username,
      'password': password,
    });
  }

  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    return _post('/auth/login', {'email': email, 'password': password});
  }

  // ── Detection ─────────────────────────────────────────────────────────────

  Future<DetectionResult> verifyText({
    required String text,
    String? title,
  }) async {
    final json = await _post('/api/verify/text', {
      'text': text,
      if (title != null) 'title': title,
    });
    return DetectionResult.fromJson(json);
  }

  Future<DetectionResult> verifyUrl(String url) async {
    final json = await _post('/api/verify/url', {'url': url});
    return DetectionResult.fromJson(json);
  }

  // ── History & Stats ───────────────────────────────────────────────────────

  Future<List<DetectionResult>> getHistory({
    int limit = 20,
    int offset = 0,
  }) async {
    final data = await _get('/api/history?limit=$limit&offset=$offset');
    return (data as List).map((j) => DetectionResult.fromJson(j)).toList();
  }

  Future<UserStats> getStats() async {
    final data = await _get('/api/stats');
    return UserStats.fromJson(data);
  }

  // ── Core HTTP helpers ─────────────────────────────────────────────────────

  Future<dynamic> _get(String path) async {
    final res = await http
        .get(Uri.parse('$_base$path'), headers: _headers)
        .timeout(const Duration(seconds: 20));
    return _handleResponse(res);
  }

  Future<dynamic> _post(String path, Map<String, dynamic> body) async {
    final res = await http
        .post(
          Uri.parse('$_base$path'),
          headers: _headers,
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 30));
    return _handleResponse(res);
  }

  dynamic _handleResponse(http.Response res) {
    final decoded = jsonDecode(res.body);
    if (res.statusCode >= 200 && res.statusCode < 300) return decoded;
    final msg = decoded['detail'] ?? 'Something went wrong';
    throw ApiException(msg, statusCode: res.statusCode);
  }
}
