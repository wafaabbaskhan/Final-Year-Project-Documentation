// lib/services/history_service.dart

import 'package:flutter/foundation.dart';
import 'api_service.dart';
import '../models/detection_result.dart';

class HistoryService extends ChangeNotifier {
  final ApiService _api;

  List<DetectionResult> _history = [];
  UserStats? _stats;
  bool _loading = false;
  String? _error;

  List<DetectionResult> get history => _history;
  UserStats? get stats => _stats;
  bool get loading => _loading;
  String? get error => _error;

  HistoryService(this._api);

  Future<void> loadHistory() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      _history = await _api.getHistory();
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> loadStats() async {
    try {
      _stats = await _api.getStats();
      notifyListeners();
    } catch (_) {}
  }

  void addResult(DetectionResult result) {
    _history.insert(0, result);
    notifyListeners();
  }
}
