# services/detector.py — AI-based fake news detection engine
# Uses an LLM (via Anthropic or OpenAI) + rule-based NLP signals

import os
import re
import json
from anthropic import Anthropic

client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

SENSATIONAL_WORDS = [
    "shocking", "bombshell", "secret", "exposed", "conspiracy",
    "they don't want you", "miracle", "cure", "cover-up",
    "exclusive", "breaking", "urgent", "you won't believe",
    "mainstream media won't tell", "banned", "censored"
]


class FakeNewsDetector:
    """
    Two-stage detector:
      Stage 1 – Rule-based NLP signals (fast, deterministic)
      Stage 2 – LLM classification (slow, nuanced)
    Final verdict is a weighted blend of both.
    """

    MODEL_VERSION = "v1.0"

    def analyze(self, text: str, title: str = "", domain: str = "") -> dict:
        if not text and not title:
            return self._empty_result()

        combined = f"{title}\n\n{text}" if title else text

        # Stage 1 — rule-based signals
        rule_signals, rule_score = self._rule_signals(combined, domain)

        # Stage 2 — LLM classification
        llm_result = self._llm_classify(combined[:4000], domain)  # limit tokens

        # Blend: 30% rules, 70% LLM
        blended_fake = 0.30 * rule_score + 0.70 * llm_result["fake_prob"]
        blended_real = 1.0 - blended_fake

        if blended_fake >= 0.65:
            verdict = "fake"
        elif blended_fake <= 0.40:
            verdict = "real"
        else:
            verdict = "uncertain"

        confidence = abs(blended_fake - 0.5) * 2  # 0–1 distance from center

        return {
            "model_version": self.MODEL_VERSION,
            "verdict": verdict,
            "fake_probability": round(blended_fake, 4),
            "real_probability": round(blended_real, 4),
            "confidence_score": round(min(confidence + 0.3, 1.0), 4),
            "signals": rule_signals + llm_result.get("signals", []),
            "tags": llm_result.get("tags", []),
        }

    # ── Stage 1: rule-based NLP ───────────────────────────────────────────────

    def _rule_signals(self, text: str, domain: str):
        signals = []
        score = 0.5  # start neutral

        lower = text.lower()

        # Sensational language check
        hits = [w for w in SENSATIONAL_WORDS if w in lower]
        if hits:
            signals.append({
                "type": "sensationalist_language",
                "label": "Sensationalist language detected",
                "weight": -min(len(hits) * 8, 34),
                "direction": "fake"
            })
            score += 0.10 * len(hits)

        # ALL CAPS words
        caps_words = re.findall(r'\b[A-Z]{4,}\b', text)
        if len(caps_words) > 3:
            signals.append({
                "type": "excessive_caps",
                "label": "Excessive capitalization",
                "weight": -10,
                "direction": "fake"
            })
            score += 0.08

        # Excessive punctuation
        if len(re.findall(r'[!?]{2,}', text)) > 2:
            signals.append({
                "type": "excessive_punctuation",
                "label": "Excessive exclamation / question marks",
                "weight": -8,
                "direction": "fake"
            })
            score += 0.06

        # Quotes from real people/institutions
        if re.search(r'(according to|said|told reporters|confirmed by)', lower):
            signals.append({
                "type": "attributed_quotes",
                "label": "Contains attributed quotes",
                "weight": +10,
                "direction": "real"
            })
            score -= 0.07

        # URLs / references
        if re.search(r'https?://', text) or re.search(r'\[\d+\]', text):
            signals.append({
                "type": "external_references",
                "label": "Contains external references or links",
                "weight": +8,
                "direction": "real"
            })
            score -= 0.05

        # Named entities (simple heuristic: Proper Nouns)
        proper_nouns = re.findall(r'\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)+\b', text)
        if len(proper_nouns) >= 3:
            signals.append({
                "type": "named_entities",
                "label": "Contains real dates and names",
                "weight": +8,
                "direction": "real"
            })
            score -= 0.05

        score = max(0.0, min(1.0, score))
        return signals, score

    # ── Stage 2: LLM classification ───────────────────────────────────────────

    def _llm_classify(self, text: str, domain: str = "") -> dict:
        domain_hint = f"The article was published on domain: {domain}." if domain else ""
        prompt = f"""You are an expert fake-news detector. Analyze the following news article and respond ONLY with a valid JSON object — no markdown, no explanation.

{domain_hint}

Article:
\"\"\"
{text}
\"\"\"

Respond with exactly this JSON structure:
{{
  "fake_prob": <float 0.0-1.0>,
  "signals": [
    {{"type": "<slug>", "label": "<human-readable>", "weight": <int -50 to +50>, "direction": "<fake|real|neutral>"}}
  ],
  "tags": ["<topic1>", "<topic2>"]
}}

Rules for fake_prob:
- 0.0 = definitely real, 1.0 = definitely fake
- Weigh: source reputation, sensationalism, lack of evidence, emotional manipulation, conspiracy claims
"""

        try:
            response = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}]
            )
            raw = response.content[0].text.strip()
            # Strip any accidental markdown fences
            raw = re.sub(r"^```json\s*|```$", "", raw, flags=re.MULTILINE).strip()
            return json.loads(raw)
        except Exception as e:
            # Fallback to neutral
            return {"fake_prob": 0.5, "signals": [], "tags": []}

    def _empty_result(self):
        return {
            "model_version": self.MODEL_VERSION,
            "verdict": "uncertain",
            "fake_probability": 0.5,
            "real_probability": 0.5,
            "confidence_score": 0.0,
            "signals": [],
            "tags": []
        }
