# services/extractor.py — Extract article text from a URL

import requests
from bs4 import BeautifulSoup
from datetime import datetime
import re


class ArticleExtractor:
    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (compatible; TruthLensBot/1.0; "
            "+https://truthlens.app/bot)"
        )
    }
    TIMEOUT = 10  # seconds

    def extract(self, url: str) -> dict | None:
        try:
            resp = requests.get(url, headers=self.HEADERS, timeout=self.TIMEOUT)
            resp.raise_for_status()
        except Exception:
            return None

        soup = BeautifulSoup(resp.text, "html.parser")

        return {
            "title":        self._get_title(soup),
            "text":         self._get_body(soup),
            "author":       self._get_author(soup),
            "published_at": self._get_date(soup),
        }

    def _get_title(self, soup):
        for sel in ["h1", "meta[property='og:title']", "title"]:
            el = soup.select_one(sel)
            if el:
                return el.get("content") or el.get_text(strip=True)
        return None

    def _get_body(self, soup):
        # Remove noise elements
        for tag in soup(["script", "style", "nav", "header",
                         "footer", "aside", "figure", "form"]):
            tag.decompose()

        # Try article tag first, then main, then body
        for container in ["article", "main", "div[class*='article']",
                          "div[class*='content']", "body"]:
            el = soup.select_one(container)
            if el:
                paragraphs = el.find_all("p")
                if len(paragraphs) >= 3:
                    text = " ".join(p.get_text(" ", strip=True) for p in paragraphs)
                    text = re.sub(r"\s+", " ", text)
                    return text[:8000]  # cap at 8k chars

        return soup.get_text(" ", strip=True)[:8000]

    def _get_author(self, soup):
        for sel in [
            "meta[name='author']",
            "[class*='author']",
            "[rel='author']",
            "[itemprop='author']"
        ]:
            el = soup.select_one(sel)
            if el:
                return el.get("content") or el.get_text(strip=True)
        return None

    def _get_date(self, soup):
        for sel in [
            "meta[property='article:published_time']",
            "meta[name='publishdate']",
            "time[datetime]",
            "[itemprop='datePublished']"
        ]:
            el = soup.select_one(sel)
            if el:
                raw = el.get("datetime") or el.get("content") or el.get_text(strip=True)
                try:
                    return datetime.fromisoformat(raw[:19])
                except Exception:
                    pass
        return None
