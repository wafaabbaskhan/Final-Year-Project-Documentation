// lib/screens/history_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/history_service.dart';
import '../models/detection_result.dart';
import 'result_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.surfaceLight,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                children: [
                  const Icon(Icons.search,
                      color: AppColors.textHint, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      style: const TextStyle(
                          color: AppColors.textPrimary, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Search past verifications…',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 12),
                      ),
                      onChanged: (v) => setState(() => _query = v.toLowerCase()),
                    ),
                  ),
                  if (_query.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        _searchCtrl.clear();
                        setState(() => _query = '');
                      },
                      child: const Icon(Icons.close,
                          color: AppColors.textHint, size: 16),
                    ),
                ],
              ),
            ),
          ),

          // List
          Expanded(
            child: Consumer<HistoryService>(
              builder: (_, hs, __) {
                if (hs.loading) {
                  return const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primary));
                }

                final items = _query.isEmpty
                    ? hs.history
                    : hs.history
                        .where((r) =>
                            (r.title ?? '').toLowerCase().contains(_query) ||
                            (r.domain ?? '').toLowerCase().contains(_query))
                        .toList();

                if (items.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _query.isEmpty
                              ? Icons.history
                              : Icons.search_off,
                          color: AppColors.textHint,
                          size: 48,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _query.isEmpty
                              ? 'No verifications yet'
                              : 'No results for "$_query"',
                          style: const TextStyle(
                              color: AppColors.textHint, fontSize: 15),
                        ),
                      ],
                    ),
                  );
                }

                // Group by date
                final grouped = _groupByDate(items);

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: grouped.length,
                  itemBuilder: (ctx, i) {
                    final section = grouped[i];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 16, bottom: 8),
                          child: Text(
                            section['label'] as String,
                            style: const TextStyle(
                                fontSize: 10,
                                color: AppColors.textHint,
                                letterSpacing: 0.8),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Column(
                            children: (section['items'] as List<DetectionResult>)
                                .asMap()
                                .entries
                                .map((e) {
                              final r = e.value;
                              final isLast = e.key ==
                                  (section['items'] as List).length - 1;
                              return Column(
                                children: [
                                  _HistoryTile(result: r),
                                  if (!isLast)
                                    const Divider(
                                        height: 1,
                                        color: AppColors.surfaceLight,
                                        indent: 54),
                                ],
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _groupByDate(List<DetectionResult> items) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));

    final Map<String, List<DetectionResult>> groups = {};

    for (final item in items) {
      final dt = DateTime(item.analyzedAt.year, item.analyzedAt.month,
          item.analyzedAt.day);
      String label;
      if (dt == today) {
        label = 'TODAY';
      } else if (dt == yesterday) {
        label = 'YESTERDAY';
      } else {
        label =
            '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
      }
      groups.putIfAbsent(label, () => []).add(item);
    }

    return groups.entries
        .map((e) => {'label': e.key, 'items': e.value})
        .toList();
  }
}

class _HistoryTile extends StatelessWidget {
  final DetectionResult result;
  const _HistoryTile({required this.result});

  @override
  Widget build(BuildContext context) {
    Color color;
    IconData icon;
    switch (result.verdict) {
      case 'fake':
        color = AppColors.verdictFake;
        icon  = Icons.warning_amber_outlined;
        break;
      case 'real':
        color = AppColors.verdictReal;
        icon  = Icons.check_circle_outline;
        break;
      default:
        color = AppColors.verdictUncertain;
        icon  = Icons.help_outline;
    }

    final pct = result.verdict == 'fake'
        ? result.fakeProbability
        : result.realProbability;

    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      leading: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(
        result.title ?? result.domain ?? 'Article',
        style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w500),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text(
          '${result.domain ?? 'Unknown'} · '
          '${_timeAgo(result.analyzedAt)} · '
          '${(pct * 100).round()}% ${result.verdict}',
          style: const TextStyle(
              color: AppColors.textHint, fontSize: 11),
        ),
      ),
      trailing: const Icon(Icons.chevron_right,
          color: AppColors.border, size: 18),
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ResultScreen(result: result))),
    );
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
